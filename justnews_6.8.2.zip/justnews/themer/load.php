<?php
/**
 * load framework required file
 * define FRAMEWORK_VERSION
 */
defined( 'ABSPATH' ) || exit;

define( 'FRAMEWORK_VERSION', '2.6.19' );
define( 'ASSETS_VERSION', '' );

require FRAMEWORK_PATH . '/core/wpcom.php';