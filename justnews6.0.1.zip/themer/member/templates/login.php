<?php
defined( 'ABSPATH' ) || exit;

global $options;
$sms_login = is_wpcom_enable_phone() && isset($options['sms_login']) && $options['sms_login'] ? $options['sms_login'] : '0';
$social_login_on = isset($options['social_login_on']) && $options['social_login_on']=='1' ? 1 : 0;
$classes = apply_filters('wpcom_login_form_classes', 'member-form-wrap member-form-login');
$logo = isset($options['login_logo']) && $options['login_logo'] ? wp_get_attachment_image_url( $options['login_logo'], 'full' ) : wpcom_logo();
?>
<div class="<?php echo $classes;?>">
    <div class="member-form-inner">
        <div class="member-form-head">
            <div class="member-form-head">
                <a class="member-form-logo" href="<?php bloginfo('url');?>" rel="home"><img class="j-lazy" src="<?php echo $logo; ?>" alt="<?php echo esc_attr(get_bloginfo( 'name' ));?>"></a>
            </div>
        </div>
        <?php if($sms_login){ ?>
            <ul class="member-form-tab">
                <li class="active"><a href="#" data-type="1"><?php $sms_login=='2' ? _e('Log in with SMS', 'wpcom') : _e('Log in with username', 'wpcom');?></a></li>
                <li><a href="#" data-type="2"><?php $sms_login!='2' ? _e('Log in with SMS', 'wpcom') : _e('Log in with username', 'wpcom');?></a></li>
            </ul>
        <?php }else{ ?>
            <div class="member-form-title">
                <h3><?php _e('Sign In', 'wpcom');?></h3>
                <span class="member-switch pull-right"><?php _e('No account?', 'wpcom');?> <a href="<?php echo wp_registration_url();?>"><?php _e('Create one!', 'wpcom');?></a></span>
            </div>
        <?php } ?>
        <?php do_action( 'wpcom_login_form' ); ?>
        <?php if( $social_login_on ){ ?>
            <div class="member-form-footer">
                <div class="member-form-social<?php echo ($sms_login?'':' member-social-full');?>">
                    <span><?php _e('Sign in with', 'wpcom');?></span>
                    <?php do_action( 'wpcom_social_login' );?>
                </div>
                <?php if($sms_login) { ?><span class="member-switch"><a href="<?php echo wp_registration_url();?>"><?php _e('Create Account', 'wpcom');?></a></span><?php } ?>
            </div>
        <?php }else if($sms_login){ ?>
            <div class="member-form-footer" style="display:block;text-align: center;">
                <span class="member-switch"><?php _e('No account?', 'wpcom');?> <a href="<?php echo wp_registration_url();?>"><?php _e('Create one!', 'wpcom');?></a></span>
            </div>
        <?php } ?>
    </div>
</div>
<a href="<?php bloginfo('url'); ?>" class="btn btn-primary btn-home"><?php WPCOM::icon('home-fill'); _e('Go back to home', 'wpcom');?></a>