<?php
// TEMPLATE NAME: 专题列表
global $options;
$num = isset($options['special_per_page']) && $options['special_per_page'] ? $options['special_per_page'] : 9;
if( isset($options['special_on']) && $options['special_on'] ) {
    $special = get_special_list($num, 1);
} else {
    $special = array();
}
get_header();?>
    <div class="wrap container">
        <?php while( have_posts() ) : the_post();?>
            <div class="special-head">
                <h1 class="special-title"><?php the_title();?></h1>
                <?php $content = get_the_content(); if($content!=='') {?><div class="page-description"><?php the_content();?></div><?php } ?>
            </div>
        <?php endwhile; ?>
        <div class="special-wrap">
            <div class="special-list clearfix">
                <?php foreach( $special as $sp ) {
                    $thumb = get_term_meta( $sp->term_id, 'wpcom_thumb', true );
                    $link = get_term_link( $sp->term_id );
                    ?>
                    <div class="col-xs-24 col-sm-8 special-item-wrap">
                        <a class="special-item" href="<?php echo $link;?>" target="_blank">
                            <div class="special-item-thumb">
                                <?php echo wpcom_lazyimg($thumb, $sp->name);?>
                                <h2 class="special-item-title"><?php echo $sp->name;?></h2>
                            </div>
                            <div class="special-item-desc"><?php echo term_description($sp->term_id, 'special');?></div>
                        </a>
                    </div>
                <?php } ?>
            </div>
            <?php $terms = get_terms(array('taxonomy' => 'special', 'hide_empty' => false)); if($terms && $num<count($terms)){ ?>
            <div class="load-more-wrap">
                <div class="btn load-more"><?php _e('Load more topics', 'wpcom');?></div>
            </div>
            <?php } ?>
        </div>
    </div>
<?php get_footer();?>